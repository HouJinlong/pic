// 页面加载完成
window.onload = () => {
  // 1. 拿到需要操作的元素
  const form1 = document.querySelector("#addForm");
  const input = document.querySelector("input[type=text]");
  let submit = document.getElementById("submit");
  let items = document.getElementById("items");
  // 2. 监听事件
  form1.addEventListener("submit", handleSubmit);
  input.addEventListener("keyup", function() {
    enableButton(submit)
  });
};

// 处理添加和编辑
function handleSubmit(e) {
  e.preventDefault();
  // 新添加Todo
  // 1. 获取要添加的todo 文本
  let newItem = document.getElementById("adder").value;
  if (newItem.trim() == "" || newItem.trim() == null)
    return false;
  else
    document.getElementById("adder").value = "";

  // 2. 创建todo元素
  let li = document.createElement("li");
  li.className = "list-group-item";

  // 添加元素到dom树
  li.appendChild(document.createTextNode(newItem));
  items.appendChild(li);
}

// 启用按钮
function enableButton(button) {
  button.disabled = false;
}



