// 1. 构建数据
// 创建的Todo初始id
let initId = 0
// 描绘Todo列表
let todos = []
// 处于编辑状态的todo
let editingTodo = null
// 用到的doms元素
let doms = {}

// 创建Todo
function createTodo(text) {
  return {
    id: ++initId,
    text,
  }
}

// 添加todo到Todos列表
function addTodoToList(todo) {
  // 检查是否存在相同的todo
  const isExist = todos.find(function(item){
    return item.id === todo.id
  })
  if (!!isExist) return
  todos.unshift(todo)
  // todos = [todo, ...todos]
}

// 编辑todo
function editTodo(id, text) {
  todos.forEach(function(todo) {
    if (todo.id === id) {
      todo.text = text
      return
    }
  })
}

// 删除todo
function deleteTodo(id) {
  todos  = todos.filter(function(todo) {
    return todo.id !== id
  })
}

// 通过id找到todo
function getTodoById(id) {
  return todos.find(function(item) {
    return item.id === id
  })
}

// 是否在编辑状态
function isEditing() {
  return !!editingTodo
}

// 设置编辑中todo
function setEditingTodo(todo){
  editingTodo = todo
}

// 清除编辑中todo
function clearEditingTodo(){
  editingTodo = null
}





// 2.构建UI
// 构建todo列表
function buildTodosList () {
  const todosHtmlArray = []
  todos.forEach(function(todo) {
    todosHtmlArray.push(buildTodoItem(todo))
  })
  const listHtml = todosHtmlArray.join('\n')
  return listHtml
}

// 构建Todo条目
function buildTodoItem(todo) {
  const todoHtml = `
    <li class="list-group-item" data-id="${todo.id}">
      ${todo.text}
      <button 
        class="btn-danger btn btn-sm float-right delete"
        data-id="${todo.id}"
      >
        删除
      </button>
      <button
        class="btn-success btn btn-sm float-right edit"
        data-id="${todo.id}"
      >
        编辑
      </button>
    </li>
  `
  return todoHtml
}

// 渲染todoList
function renderTodoList() {
  doms.items.innerHTML = buildTodosList()
}

// 更新todo添加或编辑器, 情况特俗直接操作dom
function updateTodoCreator() {
  const editing = isEditing()
  const inputValue = editing ? editingTodo.text : ""
  const submitValue = editing ? "编辑" : "添加"
  doms.input.value = inputValue
  doms.input.focus()
  doms.submit.value = submitValue
  doms.submit.disabled = !inputValue
}


// 3.处理事件
// 获取相关dom元素
function initDoms() {
  doms.form1 = document.querySelector("#addForm")
  doms.input = document.querySelector("#adder")
  doms.submit = document.getElementById("submit")
  doms.items = document.getElementById("items")
  doms.successElement = document.getElementById("lblsuccess")
}

// 绑定事件
function bindEvents () {
  doms.form1.addEventListener("submit", handleSubmit)
  doms.items.addEventListener("click", handleItemClick)
  doms.input.addEventListener("keyup", handleEnableSubmitButton)
}


// 处理编辑
function handleEdit() {
  const todoText = doms.input.value
  editTodo(editingTodo.id, todoText)
  renderTodoList()
  clearEditingTodo()
  updateTodoCreator()
  showSuccessMessage("编辑成功")
  persistentTodos()
}

// 处理添加Todo
function handleAdd() {
  // 1. 获取要添加的todo 文本
  const newTodoText = doms.input.value;
  if (newTodoText.trim() == "" || newTodoText.trim() == null)
    return false;

  // 2. 创建todo元素
  const todo = createTodo(newTodoText)
  // 3. 添加todo到数组中
  addTodoToList(todo)
  // 4. 更新视图
  renderTodoList()
  // 5. 持久化todos
  persistentTodos()
  // 6. 恢复添加器
  updateTodoCreator()
}

// 处理添加和编辑
function handleSubmit(e) {
  e.preventDefault();
  // 判断是否是在编辑
  if (isEditing()) {
    handleEdit()
    return
  }
  handleAdd()
}

// 处理删除Todo
function handleDeleteTodo (id) {
  // 删除二次确认
  if (confirm("确定吗?")) {
    deleteTodo(id)
    renderTodoList()
    persistentTodos()
    showSuccessMessage("删除成功")
  }
}

// 处理编辑Todo
function handleEditTodo (id) {
  const todo = getTodoById(id)
  setEditingTodo(todo)
  updateTodoCreator()
}

// 处理删除或编辑事件
function handleItemClick(e) {
  e.preventDefault();
  const targetClassList = e?.target?.classList
  const todoId = parseInt(e?.target?.dataset.id);
  // 删除按钮被点击
  if (targetClassList?.contains("delete")) {
    handleDeleteTodo(todoId)
    return
  }
  // 编辑按钮被点击
  if (targetClassList?.contains("edit")) {
    handleEditTodo(todoId)
    return
  }
}

// 启用按钮
function handleEnableSubmitButton() {
  doms.submit.disabled = false
}


// 4. 其他工具

// 展示编辑通知
function showSuccessMessage(msg, delay=3000) {
  const element = doms.successElement
  element.innerHTML = msg
  element.style.display = "block"
  const timer = setTimeout(function () {
    element.style.display = "none"
    clearTimeout(timer)
  }, delay);
}

// 将todos持久化
function persistentTodos() {
  window.localStorage.setItem('__todos__', JSON.stringify(todos))
}

// 读取todos, 需要更新最大的id
function loadTodos() {
  todos = JSON.parse(window.localStorage.getItem('__todos__') || '[]')
  const ids = todos.map(function(item) {
    return item.id
  })
  initId = Math.max(...ids)
}


// 初始化
function init() {
  initDoms()
  bindEvents()
  loadTodos()
  renderTodoList()
}


// 页面加载完成
window.onload = init



