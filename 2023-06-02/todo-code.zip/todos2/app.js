// 页面加载完成
window.onload = () => {
  // 1. 拿到需要操作的元素
  const form1 = document.querySelector("#addForm");
  const input = document.querySelector("input[type=text]");
  let submit = document.getElementById("submit");
  let items = document.getElementById("items");
  let editItem = null;
  // 2. 监听事件
  form1.addEventListener("submit", handleSubmit);
  items.addEventListener("click", handleItemClick);
  input.addEventListener("keyup", function() {
    enableButton(submit)
  });
};

// 处理添加和编辑
function handleSubmit(e) {
  e.preventDefault();
  // 判断是否是在编辑
  if (submit.value != "确定") {
    editItem.target.parentNode.childNodes[0].data
      = document.getElementById("adder").value;

    submit.value = "确定";
    document.getElementById("adder").value = "";

    // 添加编辑通知
    document.getElementById("lblsuccess").innerHTML
      = "编辑成功";
    document.getElementById("lblsuccess")
      .style.display = "block";
    setTimeout(function () {
      document.getElementById("lblsuccess")
        .style.display = "none";
    }, 3000);

    return false;
  }

  // 新添加Todo
  // 1. 获取要添加的todo 文本
  let newItem = document.getElementById("adder").value;
  if (newItem.trim() == "" || newItem.trim() == null)
    return false;
  else
    document.getElementById("adder").value = "";

  // 2. 创建todo元素
  let li = document.createElement("li");
  li.className = "list-group-item";

  // 创建删除按钮
  let deleteButton = document.createElement("button");
  deleteButton.className =
    "btn-danger btn btn-sm float-right delete";
  deleteButton.appendChild(document.createTextNode("删除"));

  // 创建编辑按钮
  let editButton = document.createElement("button");
  editButton.className =
    "btn-success btn btn-sm float-right edit";
  editButton.appendChild(document.createTextNode("编辑"));

  // 添加元素到dom树
  li.appendChild(document.createTextNode(newItem));
  li.appendChild(deleteButton);
  li.appendChild(editButton);
  items.appendChild(li);
}

// 处理删除
function handleItemClick(e) {
  e.preventDefault();
  // 判断是否是删除按钮
  if (e.target.classList.contains("delete")) {
    // 删除二次确认
    if (confirm("确定吗?")) {
      let li = e.target.parentNode;
      items.removeChild(li);
      document.getElementById("lblsuccess").innerHTML
        = "删除成功";

      document.getElementById("lblsuccess")
        .style.display = "block";

      setTimeout(function () {
        document.getElementById("lblsuccess")
          .style.display = "none";
      }, 3000);
    }
  }
  // 处理编辑
  if (e.target.classList.contains("edit")) {
    document.getElementById("adder").value =
      e.target.parentNode.childNodes[0].data;
    submit.value = "编辑";
    editItem = e;
  }
}

// 启用按钮
function enableButton(button) {
  button.disabled = false;
}
